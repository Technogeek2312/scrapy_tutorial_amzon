import scrapy
from ..items import AmazonLaptopsItem

class MainCodeSpider(scrapy.Spider):
    name='laptops'
    page_number = 2
    start_urls=[
        'https://www.amazon.in/s?rh=n%3A976442031%2Cn%3A%211499776031%2Cn%3A%211499778031%2Cn%3A15601078031&page=1&qid=1554659932&ref=lp_15601078031_pg_3'
    ]

    def parse(self,response):

        items = AmazonLaptopsItem()

        all_div_products=response.css('div.s-item-container')

        for products in all_div_products:

            product_name = products.css('.s-access-title::text').extract()
            company = products.css('span.a-color-secondary+ .a-color-secondary::text').extract()
            selling_price = products.css('span.s-price::text').extract()
            MRP = products.css('span.a-text-strike::text').extract()

            items['Product'] = product_name
            items['Company'] = company
            items['Selling_price'] = selling_price
            items['MRP'] = MRP

            yield items

        next_page = 'https://www.amazon.in/s?rh=n%3A976442031%2Cn%3A%211499776031%2Cn%3A%211499778031%2Cn%3A15601078031&page='+ str(MainCodeSpider.page_number)+'&qid=1554659932&ref=lp_15601078031_pg_3'
        if MainCodeSpider.page_number < 15:
            MainCodeSpider.page_number += 1
            yield response.follow(next_page,callback=self.parse)